function insta(){
    window.open('https://www.instagram.com/jayant_khanna1/','_blank')
  }
  function github(){
    window.open('https://github.com/jayantkhanna1','_blank')
  }
  function linkedln(){
    window.open('https://www.linkedin.com/in/jayant-khanna-66a274185/','_blank')
  }